import { Layout, Pagination } from "antd";

import list from "../assets/images/icons/list.svg";
import grid from "../assets/images/icons/grid.svg";
import { FireOutlined } from "@ant-design/icons";
import List from "../components/List";
import Grid from "../components/Grid";
import { useState } from "react";
import SiderComponent from "../components/Sider";
import HeaderComponent from "../components/Header";
import FooterComponent from "../components/FooterComponent";
const { Content } = Layout;

const MainRootLayout = () => {
  const [tab, setTab] = useState(1);
  const [width, setWidth] = useState("75vw");
  const [siderWidth, setSiderWidth] = useState(300);
  return (
    <Layout style={{ minHeight: "100vh", fontFamily: "unset" }}>
      <SiderComponent
        siderWidth={siderWidth}
        setSiderWidth={setSiderWidth}
        setWidth={setWidth}
      />
      <Layout>
        <HeaderComponent width={width} />
        <Content
          className={`${width}`}
          style={{
            backgroundColor: "#f6f6f6",
          }}
        >
          <div style={{ maxWidth: "850px", margin: "40px auto" }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <div style={{ display: "flex", gap: "5px" }}>
                <h2 className="text-3xl font-medium">Топ объявления</h2>
                <FireOutlined
                  style={{ fontSize: "24px", marginLeft: "20px" }}
                />
              </div>
              <div className="flex ">
                <img
                  className="hover:cursor-pointer "
                  onClick={() => setTab(1)}
                  width={28}
                  src={list}
                  alt=""
                  title="List"
                />
                <img
                  title="Grid"
                  className="hover:cursor-pointer "
                  onClick={() => setTab(2)}
                  width={28}
                  src={grid}
                  alt=""
                />
              </div>
            </div>
            {tab === 1 ? (
              new Array(4).fill(null).map((i, index) => {
                return <List key={index} />;
              })
            ) : (
              <div className="flex gap-4 flex-wrap">
                {new Array(6).fill(null).map((i, index) => {
                  return <Grid key={index} />;
                })}
              </div>
            )}
            <div className="my-10 justify-between" style={{ display: "flex" }}>
              <h2 className="text-3xl font-medium">Топ объявления</h2>
              <div className="flex gap-4">
                <select className="border-none bg-transparent" name="" id="">
                  <option value="">Самые новые</option>
                </select>
                <select className="border-none bg-transparent" name="" id="">
                  <option value="">Самые дешев</option>
                </select>
                <select className="border-none bg-transparent" name="" id="">
                  <option value="">Самые дорог</option>
                </select>
              </div>
            </div>
            {tab === 1 ? (
              new Array(8).fill(null).map((i, index) => {
                return <List key={index} />;
              })
            ) : (
              <div className="flex gap-4 flex-wrap">
                {new Array(15).fill(null).map((i, index) => {
                  return <Grid key={index} />;
                })}
              </div>
            )}
            <div className="flex justify-end my-9">
              <Pagination defaultCurrent={1} total={100} />
            </div>
          </div>
        </Content>
        <FooterComponent width={width} />
      </Layout>
    </Layout>
  );
};

export default MainRootLayout;
