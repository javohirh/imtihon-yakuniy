import React from "react";
import { FaArrowLeftLong } from "react-icons/fa6";
import { Link } from "react-router-dom";

const Check = () => {
  return (
    <div>
      <Link to={"/login"}>
        <FaArrowLeftLong />
        Вернуться
      </Link>
    </div>
  );
};

export default Check;
