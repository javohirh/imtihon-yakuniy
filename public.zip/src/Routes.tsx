import { createBrowserRouter } from "react-router-dom";
import MainRootLayout from "./layouts/MainRootLayout";
import LoginLayout from "./layouts/Loginlayout/LoginLayout";
import LoginForm from "./layouts/Loginlayout/LoginForm";

const routes = createBrowserRouter([
  {
    index: true,
    element: <MainRootLayout />,
  },
  {
    path: "login",
    element: <LoginLayout />,
    children: [
      { index: true, element: <LoginForm /> },
      {
        path: "check",
        element: (
          <>
            <h1>Hello from checking page</h1>
          </>
        ),
      },
    ],
  },
]);

export default routes;
