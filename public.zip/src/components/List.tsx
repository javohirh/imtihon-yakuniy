import listimg from "../assets/images/images/list-img.png";
import heart from "../assets/images/icons/heart.svg";
import room from "../assets/images/images/Room.png";
import area from "../assets/images/images/Area.png";
import conditon from "../assets/images/images/condition.png";
import { EyeOutlined, HeartOutlined } from "@ant-design/icons";

function List() {
  return (
    <div
      className="mt-8"
      style={{
        display: "flex",
        backgroundColor: "#fff",
        width: "100%",
        borderRadius: "10px",
        borderRight: "10px solid #FCA311",
      }}
    >
      <img style={{ width: "25%" }} src={listimg} alt="" />
      <div style={{ margin: "0px 20px ", width: "75%" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "40px",
          }}
        >
          <h2 style={{ color: "#161A1D", fontSize: "25px", margin: "5px" }}>
            Продается Hi-Tech пентхаус
          </h2>
          <HeartOutlined style={{ fontSize: "24px" }} />
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <span style={{ color: "#999999", fontSize: "15px" }}>
              <img
                style={{ marginRight: "10px", display: "inline-block" }}
                src={room}
                alt=""
              />
              28
            </span>
            <span style={{ color: "#999999", fontSize: "15px" }}>
              <img
                style={{ marginRight: "10px", display: "inline-block" }}
                src={area}
                alt=""
              />
              100 м2
            </span>
            <span style={{ color: "#999999", fontSize: "15px" }}>
              <img
                style={{ marginRight: "10px", display: "inline-block" }}
                src={conditon}
                alt=""
              />
              Евроремонт
            </span>
          </div>
          <h2 style={{ color: "#6A9B0C", fontSize: "24px" }}>$ 750,000</h2>
        </div>
        <div
          className="mt-8"
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <p style={{ color: "#161A1D", fontSize: "14px" }}>
            г.Ташкент, Юнусабадский р-н, ул.Янгишахар
          </p>
          <div style={{ display: "flex", gap: "20px" }}>
            <p style={{ color: "#999999", fontSize: "14px" }}>
              <EyeOutlined />
              12983
            </p>
            <p style={{ color: "#999999", fontSize: "14px" }}>
              Опубликовано 22:38 25-Окт 2021
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default List;
