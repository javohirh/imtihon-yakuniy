import grid from "../assets/images/images/grid-mg.png";

import room from "../assets/images/images/Room.png";
import area from "../assets/images/images/Area.png";
import conditon from "../assets/images/images/condition.png";
import { EyeOutlined, HeartFilled, HeartOutlined } from "@ant-design/icons";

function Grid() {
  return (
    <div
      className="mt-8"
      style={{
        backgroundColor: "#fff",
        maxWidth: "270px",
        borderRadius: "10px",
        borderBottom: "10px solid #FCA311",
      }}
    >
      <img src={grid} alt="" />
      <h2 style={{ color: "#161A1D", fontSize: "20px", margin: "5px" }}>
        Продается Hi-Tech пентхаус
      </h2>
      <div style={{ margin: "0px 8px " }}>
        <div
          className="mt-4 mb-8"
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "10px",
          }}
        >
          {" "}
          <h2 style={{ color: "#6A9B0C", fontSize: "24px" }}>$ 750,000</h2>
          <HeartFilled style={{ fontSize: "24px", color: "red" }} />
          <HeartOutlined style={{ fontSize: "24px", color: "red" }} />
        </div>
        <div
          className="my-4"
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <span style={{ color: "#999999", fontSize: "10px" }}>
              <img
                width={24}
                style={{ marginRight: "4px", display: "inline-block" }}
                src={room}
                alt=""
              />
              28
            </span>
            <span style={{ color: "#999999", fontSize: "10px" }}>
              <img
                width={24}
                style={{ marginRight: "4px", display: "inline-block" }}
                src={area}
                alt=""
              />
              100 м2
            </span>
            <span style={{ color: "#999999", fontSize: "10px" }}>
              <img
                width={24}
                style={{ marginRight: "4px", display: "inline-block" }}
                src={conditon}
                alt=""
              />
              Евроремонт
            </span>
          </div>
          <p style={{ color: "#999999", fontSize: "14px" }}>
            <EyeOutlined />
            12983
          </p>
        </div>
        <div
          className="mt-8 mb-2 "
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <p style={{ color: "#161A1D", fontSize: "12px" }}>
            г.Ташкент, Юнусабадский р-н, ул.Янгишахар
          </p>
          <div style={{ display: "flex", gap: "20px" }}>
            <p style={{ color: "#999999", fontSize: "12px" }}>22:38 25-Окт</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Grid;
