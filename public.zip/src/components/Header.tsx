import { Button, Select } from "antd";
import { Header } from "antd/es/layout/layout";

import Search from "antd/es/transfer/search";
import myOrder from "../assets/images/icons/MyOrders.svg";
import signUp from "../assets/images/icons/SignUp.svg";
import heart from "../assets/images/icons/heart.svg";
import { Link } from "react-router-dom";
type width = { width: string };
function HeaderComponent({ width }: width) {
  return (
    <Header
      className={`${width}`}
      style={{ padding: 0, backgroundColor: "#fff" }}
    >
      {" "}
      <div className="header-content">
        <Search placeholder="Найти объявления..." />
        <div className="header-main">
          <Button
            className="text-sm font-medium py-5"
            type="primary"
            style={{ backgroundColor: "#fca311", color: "#161A1D" }}
          >
            Разместить объявление
          </Button>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <img src={myOrder} alt="" />
            <img src={heart} alt="" />
            <Link to={"login"}>
              <img src={signUp} alt="" />
            </Link>
          </div>
          <Select
            className="custom-select"
            defaultValue="RU"
            style={{ width: 60 }}
            options={[
              { value: "ru", label: "Ru" },
              { value: "uz", label: "UZ" },
              { value: "en", label: "EN" },
            ]}
          />
        </div>
      </div>
    </Header>
  );
}

export default HeaderComponent;
