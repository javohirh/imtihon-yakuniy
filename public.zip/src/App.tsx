import { RouterProvider } from "react-router-dom";
import routes from "./Routes";
import React from "react";

const App: React.FC = () => {
  return (
    <>
      <RouterProvider router={routes}></RouterProvider>
    </>
  );
};

export default App;
