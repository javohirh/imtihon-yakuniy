import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

type Store = {
  phone: string | null;
  name: string | null;
  token: string | null;
  setPhone: (e: string) => void;
  setName: (e: string) => void;
  setToken: (e: string) => void;
};

const useStore = create<Store>()(
  persist(
    (set) => ({
      token: null,
      phone: null,
      name: null,

      setPhone: (e: string) => set((state) => ({ ...state, phone: e })),
      setName: (e: string) => set((state) => ({ ...state, name: e })),
      setToken: (e: string) => set((state) => ({ ...state, token: e })),
    }),
    {
      name: "user-storage",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        phone: state.phone,
        name: state.name,
        token: state.token,
      }),
    }
  )
);

export default useStore;
